# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'li
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

hello <- function() {
  print("Hello, world!")
}



#VOLUME-VOLUME BANGUN RUANG

#VOLUME SILINDER
VolumeSilinder<-function(jari.jari,tinggi)
{VolumeSilinder<-pi*jari.jari^2*tinggi
cat("Silinder Tabung Tersebut Memiliki Volume", VolumeSilinder)
cat(" cm^3")
}

VolumeSilinder(7,8)

#VOLUME KUBUS
VolumeKubus<-function(sisi)
{VolumeKubus<-sisi^3
cat("Kubus Tersebut Memiliki Volume", VolumeKubus)
cat(" cm^3")
}

VolumeKubus(2)

#VOLUME LIMAS
VolumeLimas<-function(alas,tinggi)
{VolumeLimas<- (1/3)*((1/2)*alas*tinggi)*tinggi
cat("Limas Tersebut Memiliki Volume", VolumeLimas)
cat(" cm^3")
}

VolumeLimas(5,8)

#VOLUME BALOK
VolumeBalok<-function(panjang,lebar,tinggi)
{VolumeBalok<-panjang*lebar*tinggi
cat("Balok Tersebut Memiliki Volume", VolumeBalok)
cat(" cm^3")
}
VolumeBalok(6,8,4)

#VOLUME KERUCUT
VolumeKerucut<-function(r,tinggi)
{VolumeKerucut<-(1/3)*pi*r^2*tinggi
cat("Kerucut Tersebut Memiliki Volume", VolumeKerucut)
cat(" cm^3")
}
VolumeKerucut(2,3)

#VOLUME TABUNG
VolumeTabung<-function(r,tinggi)
{VolumeTabung<-pi*r^2*tinggi
cat("Tabung Tersebut Memiliki Volume", VolumeTabung)
cat(" cm^3")}
VolumeTabung(4,5)

#VOLUME PRISMA
VolumePrisma<-function(panjang,lebar,tinggi)
{VolumePrisma<-(1/2)*panjang*lebar*tinggi
cat("Prisma Tersebut Memiliki Volume", VolumePrisma)
cat(" cm^3")}
VolumePrisma(3,5,7)

#LUAS-LUAS BANGUN DATAR
#LUAS SEGITIGA
LuasSegitiga = function(alas,tinggi)
{LuasSegitiga=(1/2)*alas*tinggi
cat("luasnya adalah :",LuasSegitiga)
cat(" cm^2")}

luasst(4,10)

#LUAS PERSEGI
luasp = function(sisi)
{luas=sisi^2
cat("luasnya adalah :",luas)}

luasp(5)

#LUAS PERSEGI PANJANG
luaspp = function(panjang,lebar)
{luas=panjang*lebar
cat("luasnya adalah :",luas)}

luaspp(3,7)

#LUAS LINGKARAN
luasl = function(r)
{luas=pi*r^2
cat("luasnya adalah :",luas)}

luasl(7)

#LUAS LAYANG LAYANG
luasll = function(d1,d2)
{luas=(1/2)*d1*d2
cat("luasnya adalah :",luas)}

luasll(4,8)

#LUAS JAJAR GENJANG
luasst <- function(alas, tinggi)
{
  Luas <- alas*tinggi
  cat("Luasnya adalah :", Luas)
}
luasst(3,6)

#LUAS TRAPESIUM
luasst <- function(atas, bawah, tinggi)
{
  Luas <- (1/2)*tinggi*(atas+bawah)
  cat("Luasnya adalah :", Luas)
}
luasst(3,4,6)

#LUAS BELAH KETUPAT
luasst <- function(d1, d2)
{
  Luas <- (1/2)*d1*d2
  cat("Luasnya adalah :", Luas)
}
luasst(4,6)

#' Geometry package: perimeter, circumference, and area calculations
#'
#' @docType package
#' @name geometry
#'
#' @importFrom stats mean
#'

#' @importFrom stats sum

#' @importFrom stats pi
#' Calculate perimeter and area of a square
#'
#' @param s Length of a side of the square
#'
#' @return A list with perimeter and area
#' @export
square <- function(s) {
  perimeter <- 4 * s
  area <- s^2
  list(perimeter = perimeter, area = area)
}

#' Calculate perimeter and area of a triangle
#'
#' @param a Length of side a
#' @param b Length of side b
#' @param c Length of side c
#'
#' @return A list with perimeter and area
#' @export
triangle <- function(a, b, c) {
  perimeter <- a + b + c
  s <- perimeter / 2
  area <- sqrt(s * (s - a) * (s - b) * (s - c))
  list(perimeter = perimeter, area = area)
}

#' Calculate circumference and area of a circle
#'
#' @param r Radius of the circle
#'
#' @return A list with circumference and area
#' @export
circle <- function(r) {
  circumference <- 2 * pi * r
  area <- pi * r^2
  list(circumference = circumference, area = area)
}

#' Calculate perimeter and area of a rectangle
#'
#' @param p Length of the rectangle
#' @param l Width of the rectangle
#'
#' @return A list with perimeter and area
#' @export
rectangle <- function(p, l) {
  perimeter <- 2 * (p + l)
  area <- p * l
  list(perimeter = perimeter, area = area)
}
